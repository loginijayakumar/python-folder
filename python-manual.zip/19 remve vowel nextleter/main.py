# n=input()
# s=""
# k=0
# for i in n:
#     if i   in"aeiouAEIOU":
#         s+=i
#     # else:
#     #   s+=n[k]
#     k+=1
# print(s)

s=input()
n=len(s)
x=s[0]
for i in range(1,n):
    if s[i-1] not in 'aeiouAEIOU':
        x+=s[i]
print(x)
# Science Fiction