n=input()
m=n.lower()
c=0;u=0
k=""
for i in m:
    if i not in k:
        c=0
        for j in m:
         if i==j:
             c+=1
        k+=i 
        # if i not in k:
        print(i,"-",c,end=' ')
        if u<c:
            s=i
            u=c
print("\n",s)
# charaCter
