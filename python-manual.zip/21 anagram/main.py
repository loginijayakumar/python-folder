# n=input()
# n1=input()
# if n.__contains__(n1) :
#     print("yes")
# else:
#     print("no")
    
n=sorted(input())
b=sorted(input())
if n==b:
    print("anagram")
else:
    print("not anagram")

