n=[int(i)  for  i in input().split(" ")]
n.sort()
m=[]
m1=[]
for i in n:
    if i>0:
        m.append(i)   
    else:
      m1.append(i);
m.extend(m1)
print(m)
# 12 14 -5 18 -6 -7
# [12, 14, 18, -7, -6, -5]


# -12 -14 0 -18 5 -6 -7

# [5, -18, -14, -12, -7, -6, 0]