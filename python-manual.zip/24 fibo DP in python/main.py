# n=int(input())
# li=[]
# a=-1;b=-1;c=0;i=1
# while i<n:
#     c=a+b
#     li.append(c)
#     a=b
#     b=c
#     i+=1
# print(li)
li=[]
res=0
def fibo(n):
    if n in li:
        return li[n]
    elif n==0:
        res=0
    elif n==1:
        res=1 
    else:
        res=fibo(n-1)+(n-2)
    li[n]=res
    
    return res
n=int(input())
print(fibo(n))