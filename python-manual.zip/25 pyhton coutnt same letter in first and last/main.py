n=input().split();c=0
for i in n:
    if i[0]==i[-1] and len(i)>1:
        c+=1
print(c)