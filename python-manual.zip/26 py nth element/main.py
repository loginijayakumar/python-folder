m=input()
n=int(input())
l=[]
for i in range(n):
    l.append(m[i::n])
print(l)
# abcdefghijklmn