n=int(input())
l=[[int(i) for i in input().split()[:n]]for i in range(n)]
s=0;t=0
for i in range(n):
    for j in range(n):
        if i>j:
            s+=l[i][j]
        elif i<j:
            t+=l[i][j]
       
print(abs(s-t))
# 3
# 18 91 12 
# 27 42 56
# 71 34 82 
