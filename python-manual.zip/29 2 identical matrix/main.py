n=int(input())
a=[[int(i) for i in input().split()[:n]] for i in range(n)]
b=[[int(i) for i in input().split()[:n]] for i in range(n)]
s=0;mat=[]
for i in range(n):
    l=[]
    for j in range(n):
        for k in range(n):
            s+=a[i][k]*b[k][j]
        l.append(s)
        s=0
    mat.append(l)
for i in mat:
    for j in i:
        print("%-3d"%j,end=" ")
    print()
# print('{:3d}'.format(j),end=" ")


