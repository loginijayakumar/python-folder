n=int(input())
a=[[int(i) for i in input().split()[:n]] for  i in range(n)]
b=[[int(i) for i in input().split()[:n]] for i in  range(n)]
c=[]
for i in range(n):
    t=[]
    for j in range(n):
        s=0
        for k in range(n):
            s+=a[i][k]*b[k][j]
        t.append(s)
    t.append(t)
print(t)
# 3
# 1 2 3
# 4 5 6
# 7 8 9
# 9 8 7     
# 6 5 4
# 3 2 1