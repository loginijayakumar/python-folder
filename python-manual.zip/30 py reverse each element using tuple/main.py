# n=[int(i) for i in input().split(",")]
# tu=tuple(n)
# tu=tuple(int(str(i)[::-1]) for i in tu)
# print(*tu,sep=',')
# 123,15,91,23,42,7
n=tuple([i[::-1] for i in input().split(',')])
print(*n,sep=',')

