s=set([int(i) for i in input().split(",")])
s1=set([int(i) for i in input().split(",")])
print(s&s1,end=' ')
print(s|s1)
# 1,2,3,4,5,6
# 4,6,8,10
