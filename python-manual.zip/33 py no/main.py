# tup=[int(i) for i in input().split(",")]
# tup.sort()
# n=int(input())
# print(tup[n-1],end=' ')
# tup=tup[::-1]
# print(tup[n-1])


# tup=[int(i) for i in input().split(",")]
# # tup.sort()
# n=int(input())
# print(tup[n-1],end=' ')
# print(tup[-n])

t=tuple(int(i) for i in input().split(","))
n=int(input())
k=sorted(t)
print(k[n-1],k[-n])
