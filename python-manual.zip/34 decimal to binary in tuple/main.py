n=input().split(",")
tu=tuple(n)
# for i in range(0,len(tu)):
#    print(bin(int(tu[i]))[2:],end=',')
# print("\b")
tu=tuple(bin(int(tu))[2:])





# 123,15,23,42,7