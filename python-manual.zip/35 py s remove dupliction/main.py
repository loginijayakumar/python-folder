def spl(n):
    l2=[]
    while n:
        l2.append(n%10)
        n//=10
    l2=l2[::-1]
    return l2
tup = [int(i) for i in input().split(",")]
l=[]
for i in tup:
    l.extend(spl(i))
tup=[]
for i in l:
    if i not in tup:
        tup.append(i)
print(*tup,sep=",")
# 23,49,122,135,98