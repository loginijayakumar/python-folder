n=input().split(",")
m=[]
m1=[]
m2=[]

for i in n:
   if i.isdigit():
      m.append(i)
   elif i.isalpha():
      m1.append(i)
   else:
      m2.append(i)
m=tuple(m)
m1=tuple(m1)
m2=tuple(m2)
print(*m,sep=',')
print(*m1,sep=',')
print(*m2,sep=',')
# 23,tuple,3.14,7.5,rock,7