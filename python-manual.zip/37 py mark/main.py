# n=int(input())
# l=[]
# for i in range(n):
#     v=input().split()
#     tot=int(v[1])+int(v[2])+int(v[3])
#     d={'Name:',v[0],'Total:',tot}
#     l.append(d)
# for i in range(n):
#     for j in range(i+1,n):
#        if l[i]['Total']<l[j]['Total']:
#             l[i],l[j]=l[j],l[i]
# s=[]
# for i in range(n):
#     s.append(l[i]['Name'])
# print(*s,sep=',')

n=int(input())
l=[]
for i in range(n):
  v=[i for i in input().split()[:4]]
  l.append(v)
d={}
for i in range(len(l)):
  n=l[i][0]
  t=l[i][1::]
  s = sum([int(i) for i in t])
  d.update({n:s})

s =sorted(d.items(),reverse=True,key=lambda d:d[1])
e=''
for i in s:
  e+=i[0]+','
print(e.strip(','))
   


d={};g=[]
n=int(input())
for i in range(n):
  l=[i for i in input().split()]
  d[l[0]]=int(l[1])+int(l[2])+int(l[3])
s=sorted(d.items(),reverse=True,key=lambda a:a[1])
for i in s:
  g.append(i[0])
print(*g,sep=",")

# tot=0
# l=[]
# d={}
# t=''
# n=int(input())
# for i in range(n):
#     tot=0
#     l=input().split()
#     t=(l[0])
#     tot=sum(int(i) for i in (l[1:]))
#     d.update({tot:t})
# l=list(d.keys())
# l.sort(reverse=True)
# t=''
# for i in l:
#     t+=d.get(i)+','
# print(t.strip(','))

 # 3
 # Akil 90 95 96
 # shanker 20 34 45
 # ravi 20 45 44
 
#  3
# ak 90 95 96
# sh 20 34 45
# ra 90 95 96

