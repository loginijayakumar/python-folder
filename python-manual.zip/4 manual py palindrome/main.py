t=n=int(input())
f=1
i=2
s=0
while i<=n//2:
   if n%i==0:
        print("not");
        break
   i+=1
   
else:
        while n:
                s=s*10+n%10
                n//=10
        print(s==t and "Prime polindrame" or "Not")

   


