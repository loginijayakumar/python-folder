n=int(input())
i=0
for i in range(1,n+n):
    if i>n:
        i=2*n-i
    print((n-i)*" "+i*"* ")
    
   
# for i in range(n,0):
#     print(i*"*")