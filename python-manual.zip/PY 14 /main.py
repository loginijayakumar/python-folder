def prim(co,l,n,su):
     j=2
     f=1
     i=l
     if su==n:
         k=1
        #  print ("yes")
     if n<su or co==2:
          return k
     for i in range(2,n):
          f=1
          for j in range(2,i//2):
                if i%j==0:
                  f=0
                  break
          if f==1:
        #       print(i)
              prim(co+1,i+1,n,su+i)
          i+=1  
                
n=int(input())
print(prim(0,2,n,0)==1 and "yes" or "no")
# print(k==1 and "yes" or "no")
# print(k==0 and"no" or "yes" )


