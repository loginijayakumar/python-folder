n=int(input())
f=1
for i in range(2,n):
        f=1
        for j in range(2,i):
                if i%j==0:
                        f=0
                        break
        if f==1:
                print(i)
                