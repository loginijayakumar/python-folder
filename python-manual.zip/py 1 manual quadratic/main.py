a=int(input())
b=int(input())
c=int(input())

x=int((-b+(b*b-4*a*c)**0.5)//(2*a))
x1=int((-b-(b*b-4*a*c)**0.5)//(2*a))
print(x,x1,sep=" ")
