def octal(a):
     c=1
     s=0
     while a:
         s=s+a%8*c
         c*=10
         a//=8
     return s
b=int(input())
a=0
k=1

while b:
    if b%10!=0:
        a+=k
    k*=2
    b//=10
print(octal(a))
