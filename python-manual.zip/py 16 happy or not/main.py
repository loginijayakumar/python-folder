def hap(n):
    s=0
    while n:
        s+=(n%10)**2
        n//=10
    if s>9:
        return hap(s)
    else:
      return s

n=int(input())
print(hap(n)==1 and "Happy" or "Not")
#  1, 7, 10, 13, 19, 23, 28, 31, 32, 44, 49, 68, 70, 79, 82, 86, 91, 94, 97, 100,
