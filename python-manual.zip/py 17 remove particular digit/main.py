def dig(n,a):
    s=0
    b=1
    # for i in n:
    #     if i not in a:
    #         s+=int(i)*b
    #         b*=10
    while n:
        if n%10!=a:
            s+=n%10*b
            b*=10
        
        n//=10
            
    return s
# def rev1(n):
#     s=0
#     while n:
#         s=s*10+n%10
#         n//=10
#     return s
n=int(input())
a=int(input())
print(dig(n,a))

