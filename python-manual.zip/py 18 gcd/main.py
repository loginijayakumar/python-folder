# n=input()
# k=1
# l=0
# # =print(ord(n))
# for i in n:
#     # print(ord(i))
#     k=1
#               print(k)
#     for j in range(1,ord(i)+1):
#         if ord(i)%int(j)==0:
#         #   print(k)
          
#           if l>=k:
#               print(k)
#               l=k
#         k+=1


def gcd(a,b):
    return b if a==0 else gcd(b%a,a)
s=input()
g=ord(s[0])
for i in s:
    g=gcd(g,ord(i))
print(g)

    
    
# 84
# 69
# 81

