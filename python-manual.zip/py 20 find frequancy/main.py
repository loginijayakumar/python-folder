s=input().lower()
d="";l=0;x=""
for  i in s:
    if i not in d and i.isalpha():
        print(i,s.count(i),sep="-",end=" ")
    d+=i
    if s.count(i)>l:
        l=s.count(i)
        x=i
print("\n",x,sep="")