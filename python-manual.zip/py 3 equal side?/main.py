a=int(input())
b=int(input())
c=int(input())

# if a==b==c:
#     print("Equilateral")
# elif a==b!=c or b==c!=a or c==a!=b:
#     print("Isosceles")
# elif a!=b!=c:
#     print("Scalene")
print(a==b==c  and "Equilateral" or a==b or b==c or c==a and  "Isosceles" or "Scalene")

