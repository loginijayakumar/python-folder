n=int(input())
s=0
while n>0:
    s+=(n%10)**2
    n//=10
#print(s)
# sq=s**0.5
if int(s**0.5) == s**0.5:
    print("yes")
else:
    print("no")
# if int(s**0.5) == s**0.5: ithum work aagum
