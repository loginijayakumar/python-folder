# n=int(input())
# i=1
# while i<=n:
#     if (n%i and n%i+1) and==0:
#      i+=1
# if f==1:
#     print("pronic")
# else:
#     print("Not pronic")
# #  0, 2, 6, 12, 20, 30, 42, 56, 72, 90, 110, 132, 156, 182, 210, 240, 272, 306, 342, 380, 420, 462 .




n=int(input())
s=int(n**0.5)
print(s)
print('pronic') if s*(s+1)==n else print("not")

# i=1
# s=1
# s1=0
# f=0

# while i<=n:
#     if n%i==0:
#         if i-s==1:
#             s1=s*i
#         s=i
#         # print(i,end=" ")
#     if s1==n:
#             f=1
#             break    
#     i+=1
# if f==1:
#     print("pronic")
# else:
#     print("Not pronic")
# # #  0, 2, 6, 12, 20, 30, 42, 56, 72, 90, 110, 132, 156, 182, 210, 240, 272, 306, 342, 380, 420, 462 .



