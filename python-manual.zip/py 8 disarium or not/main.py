m1=m=n=int(input())
c=0
while m1:
        c+=1
        m1//=10
d=0

while n>0:
    
    d+=(n%10)**c
    c-=1
    n//=10
    
print(d==m and "Disarium" or "Not")
