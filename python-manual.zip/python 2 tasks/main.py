'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
a=int(input());b=int(input());c=int(input())
# n=a>b and a>c and b>c or b and c
# print(n)
# if a>b and a>c:
#     print(a,sep=' ')
# elif b>c:
#     print(b,sep=' ')
# else:
#     print(c,sep=' ')
# if a<b and a<c:
#     print(a,sep=' ')
# elif b<c:
#     print(b,sep=' ')
# else:
#     print(c,sep=' ')
print((a>b and a>c and a or b>c and b or c),(a<b and a<c and a or b<c and b or c))

