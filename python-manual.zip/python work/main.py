
    #identity
# s1="kong";s2="kong"
# print(s1  is  s2)
'''
l1=[]
l2=[]
l3=l2
print(l1  is l2)#False yena same value but differnt address
print(l2 is l3)#True yena same value  same address
'''
'''
l1=[1,2]
l2=[1,2]
l2[0]=8 vaulue change aaguthu list la
l3=l1
l3[0]=5  vaulue change aaguthu list la
print(l1)#[5,2]
print(l2)#[8,2]
'''
          #INPUT AND OUTPUT
s=input() #get only String 
a=int(input()) #int input
b=float(input())#float input
c=complex(input())#complex input 2+1j
d=bool(input())#boolean input

x=50
y=100
print(x+y)


