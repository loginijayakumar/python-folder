import java.util.*;
class rec{
  static int k=0;
  void pri(int count,int l,int n,int sum)
  {  int f=1,i,j;
    
    if(sum==n){
      k=1;
    //   System.out.println("yes");
      }
      if(n<sum||count==2)
        return;
    for( i=l; i<n; i++){
      f=1;
        for( j=2; j<=i/2; j++){
          if(i%j==0){
            f=0;
            break;
            }
          }
          if(f==1)
            pri(count+1,i+1,n,sum+i);
            
      }
    
  }
}
class Main{
    public static void main(String ar[]){
      Scanner sc=new Scanner(System. in);
      int n=sc.nextInt();
      rec r=new rec();
      r.pri(0,2,n,0);
      if(rec.k==1)
      System.out.println("True");
      else
      System.out.println("False");
      }
  }