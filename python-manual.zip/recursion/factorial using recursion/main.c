
#include <stdio.h>

int fact(int n)
{
    if(n==0)
      return 1;
    return n*fact(n-1);// sum of n numbers is n+fact(n-1);if(n==0)return 0;
}
int main()
{
int n;
scanf("%d",&n);
printf("%d",fact(n));

    return 0;
}


// // sum of numbers secomd mesthod
// #include <stdio.h>

// int fact(int i,int sum)
// {
//     if(i==0)
//     {printf("%d",sum);
//       return 0;
//     }
//     return fact(i-1,sum+i);// sum of n numbers is n+fact(n-1);if(n==0)return 0;
// }
// int main()
// {
// int n;
// scanf("%d",&n);
// fact(n,0);
// // printf("%d",fact(n,0));

//     return 0;
// }
