#include <stdio.h>
int count=0;
void nex(int);
void num(int n)
{    
    count++;
    printf("%d ",count);
    if(count>=n)
      return;
    else 
    {
    //  nex(n);
      num(n);
      
    }
}
// void nex(int n)
// {
//     int c=n;
//     c--;
//     printf("%d ",c);
//     if(1>=c)
//       return;
//     else
//       {
//           num(c);
//           nex(n);
//       }
    
// }
int main()
{
    int n;
    scanf("%d",&n);
    num(n);
    return 0;
}
