//5
//1 2 3 4 5
/*#include <stdio.h>
void fun1(int i,int n)
{
    if(i>n)
    return;
    printf("%d ",i);
    fun1(i+1,n);
}
int main()
{
    int n;
    scanf("%d",&n);
    fun1(1,n);

    return 0;
}*/


// 10
// 10 9 8 7 6 5 4 3 2 1 
/*#include <stdio.h>
void fun1(int i,int n)
{
    if(i<1)
    return;
    printf("%d ",i);
    fun1(i-1,n);
}
int main()
{
    int n;
    scanf("%d",&n);
    fun1(n,n);

    return 0;
}
*/


//n numbers printng backward procces
// 10
// 1 2 3 4 5 6 7 8 9 10 
/*#include <stdio.h>
void fun1(int i,int n)
{
    if(i<1)
    return;
    //printf("%d ",i);
    fun1(i-1,n);
    printf("%d ",i);
}
int main()
{
    int n;
    scanf("%d",&n);
    fun1(n,n);

    return 0;
}*/

// n numbers revverse printing backward procces
// 10
// 10 9 8 7 6 5 4 3 2 1

#include <stdio.h>
void fun1(int i,int n)
{
    if(i>n)
    return;
    //printf("%d ",i);
    fun1(i+1,n);
    printf("%d ",i);
}
int main()
{
    int n;
    scanf("%d",&n);
    fun1(1,n);

    return 0;
}