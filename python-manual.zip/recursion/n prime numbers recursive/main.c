/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void prim(int l,int n)
{
   int i,j,f=1;
   for(i=l;i<=n;i++)
   {
      f=1;
      for(j=2;j<=i/2;j++)
      {
         if(i%j==0)
           {
              f=0;
              break;
           }
      }
      if(f==1)
        printf("%d ",i);
      
   }
   if(i>=n)
      return;
   prim(i+1,n);
}
int main()
{
    int i,n;
    scanf("%d",&n);
    prim(2,n);

    return 0;
}
