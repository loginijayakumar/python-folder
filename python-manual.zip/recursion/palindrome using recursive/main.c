
#include <stdio.h>
int swap(int i,int a[],int n)
{
    int f=1;
    if(i>=n/2)
      return;
    if(a[i]!=a[n-i-1])
       return f;
    swap(i+1,a,n-1);
}
int main()
{
  int i,a[1000],n;
  scanf("%d",&n);
  for(i=1;i<=n;i++)
  {
      scanf("%d",&a[i]);
  }
  printf("%d",swap(1,a,n));
    return 0;
}
