import java.util.*;
class str
{
    
  String s1,h;
String rev(String s[],int i)
{   
  if(i--==0)
     return "/";
    // System.out.print(s[i]+"\n"); 
    if(!(s[i].equals(null)))
    {
        s1+=s[i]+" ";
        rev(s,i);
    }
    return s1;
    
}
}
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
		String s[]=sc.nextLine().split(" ");
		str obj=new str();
		System.out.print(obj.rev(s,s.length));
	}
}
