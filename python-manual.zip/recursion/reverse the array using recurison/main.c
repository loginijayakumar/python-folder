
// #include <stdio.h>
// void swap(int i,int a[],int n)
// {
//     int t=0;
//     if(i>=n/2)
//       return;
//     t=a[i];
//     a[i]=a[n-i-1];
//     a[n-i-1]=t;
//     swap(i+1,a,n);
// }
// int main()
// {
//   int i,a[1000],n;
//   scanf("%d",&n);
//   for(i=1;i<=n;i++)
//   {
//       scanf("%d",&a[i]);
//   }
//   swap(1,a,n);
//   for(i=1;i<=n;i++)
//   {
//       printf("%d ",a[i]);
//   }

//     return 0;
// }

/// second method

#include <stdio.h>
void swap(int l,int a[],int r)
{
    int t=0;
    if(l>=r)
      return;
    t=a[l];
    a[l]=a[r];
    a[r]=t;
    swap(l+1,a,r-1);
}
int main()
{
  int i,a[1000],n;
  scanf("%d",&n);
  for(i=1;i<=n;i++)
  {
      scanf("%d",&a[i]);
  }
  swap(1,a,n);
  for(i=1;i<=n;i++)
  {
      printf("%d ",a[i]);
  }

    return 0;
}
